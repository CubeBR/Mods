Barbecue_Icons by Salatiel (http://www.cubebr.com/)

Some files are modified content from Sauerbraten.

v 27/12/2017
